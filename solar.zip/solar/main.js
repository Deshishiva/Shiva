const canvas = document.getElementById("solarCanvas");
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);
const renderer = new THREE.WebGLRenderer({ canvas });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Lighting
const ambientLight = new THREE.AmbientLight(0x888888);
scene.add(ambientLight);
const pointLight = new THREE.PointLight(0xffffff, 2, 500);
pointLight.position.set(0, 0, 0);
scene.add(pointLight);
const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
directionalLight.position.set(0, 0, 50);
scene.add(directionalLight);

// Sun
const sunGeometry = new THREE.SphereGeometry(3, 32, 32);
const sunMaterial = new THREE.MeshBasicMaterial({ color: 0xffff00 });
const sun = new THREE.Mesh(sunGeometry, sunMaterial);
scene.add(sun);

// Updated planet spacing
const planetsData = [
  { name: "Mercury", color: 0xaaaaaa, size: 0.4, distance: 8, speed: 0.04 },
  { name: "Venus", color: 0xffcc66, size: 0.9, distance: 12, speed: 0.015 },
  { name: "Earth", color: 0x3399ff, size: 1, distance: 16, speed: 0.01 },
  { name: "Mars", color: 0xff3300, size: 0.8, distance: 20, speed: 0.008 },
  { name: "Jupiter", color: 0xff9966, size: 2, distance: 26, speed: 0.002 },
  { name: "Saturn", color: 0xffcc99, size: 1.7, distance: 34, speed: 0.001 },
  { name: "Uranus", color: 0x66ccff, size: 1.5, distance: 42, speed: 0.0005 },
  { name: "Neptune", color: 0x3366ff, size: 1.5, distance: 50, speed: 0.0003 },
];

const planetMeshes = [];
const speeds = {};

planetsData.forEach((planet) => {
  const geometry = new THREE.SphereGeometry(planet.size, 32, 32);
  const material = new THREE.MeshPhongMaterial({ color: planet.color, shininess: 10 });
  const mesh = new THREE.Mesh(geometry, material);
  scene.add(mesh);
  planetMeshes.push({ mesh, data: planet });

  speeds[planet.name] = planet.speed;
  planet.angle = Math.random() * Math.PI * 2;

  // Create slider control
  const label = document.createElement("label");
  label.innerHTML = `${planet.name}: <input type="range" min="0.0001" max="0.1" step="0.0001" value="${planet.speed}" id="${planet.name}Slider">`;
  document.getElementById("controls").appendChild(label);

  document.getElementById(`${planet.name}Slider`).addEventListener("input", (e) => {
    speeds[planet.name] = parseFloat(e.target.value);
  });
});

camera.position.z = 80;

// Pause/Resume
let paused = false;
document.getElementById("pauseBtn").onclick = () => (paused = true);
document.getElementById("resumeBtn").onclick = () => (paused = false);

// Add background stars
function addStars(count = 1000) {
  const geometry = new THREE.BufferGeometry();
  const positions = [];
  for (let i = 0; i < count; i++) {
    const x = (Math.random() - 0.5) * 1000;
    const y = (Math.random() - 0.5) * 1000;
    const z = (Math.random() - 0.5) * 1000;
    positions.push(x, y, z);
  }
  geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  const material = new THREE.PointsMaterial({ color: 0xffffff, size: 0.7 });
  const stars = new THREE.Points(geometry, material);
  scene.add(stars);
}
addStars();

// Tooltip and hover label
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
const tooltip = document.getElementById("tooltip");

window.addEventListener("mousemove", (event) => {
  mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
  mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
});

function checkHover(event) {
  raycaster.setFromCamera(mouse, camera);
  const intersects = raycaster.intersectObjects(planetMeshes.map(p => p.mesh));
  if (intersects.length > 0) {
    const mesh = intersects[0].object;
    const planet = planetMeshes.find(p => p.mesh === mesh);
    tooltip.innerText = planet.data.name;
    tooltip.style.left = event.clientX + 10 + "px";
    tooltip.style.top = event.clientY + 10 + "px";
    tooltip.style.display = "block";
  } else {
    tooltip.style.display = "none";
  }
}

// Click-to-zoom on planet
window.addEventListener("click", () => {
  raycaster.setFromCamera(mouse, camera);
  const intersects = raycaster.intersectObjects(planetMeshes.map(p => p.mesh));
  if (intersects.length > 0) {
    const mesh = intersects[0].object;
    camera.position.set(mesh.position.x * 1.5, mesh.position.y + 2, mesh.position.z * 1.5);
    camera.lookAt(mesh.position);
  }
});

// Animate
function animate() {
  requestAnimationFrame(animate);
  if (!paused) {
    planetMeshes.forEach(({ mesh, data }) => {
      data.angle += speeds[data.name];
      mesh.position.x = Math.cos(data.angle) * data.distance;
      mesh.position.z = Math.sin(data.angle) * data.distance;
    });
  }
  checkHover();
  renderer.render(scene, camera);
}
animate();

window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
